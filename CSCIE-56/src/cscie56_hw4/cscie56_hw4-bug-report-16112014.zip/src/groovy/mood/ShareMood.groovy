package mood

import com.nerds.Post

/**
 * Created by ashbig on 11/15/2014.
 */
public enum ShareMood {
        HAPPY('Happy!'),
        SAD('sad :('),
        FRUSTRATED('Feeling Frustrated! (>_<)'),
        INSPIRED('Inspired!'),
        ANGRY('grrr!')

        static belongsTo = [post: Post ]
}