package com.freezers

/**
 * Created by ashbig on 12/9/2014.
 */
class Rack {

    Plate [][] racks = new Plate[25][25]

    static belongsTo = [Shelf]
    static hasMany = [plates: Plate]

}
