package com.freezers

/**
 * Created by ashbig on 12/9/2014.
 */
class Plate {
    String name

    static belongsTo = [Rack]
    static constraints = {
        name size: 1..30, nullable: true
    }
}
