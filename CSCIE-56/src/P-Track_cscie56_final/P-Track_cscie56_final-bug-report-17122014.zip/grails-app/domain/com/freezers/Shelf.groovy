package com.freezers

/**
 * Created by ashbig on 12/9/2014.
 */
class Shelf {

    Rack [] shelve

    static belongsTo = [Freezer]
    static hasMany = [ racks : Rack]

    public shelf ( int shelves ) {
        for ( int j = 0; j < i; i ++){
            shelve.add(new Rack());
        }
    }
}
