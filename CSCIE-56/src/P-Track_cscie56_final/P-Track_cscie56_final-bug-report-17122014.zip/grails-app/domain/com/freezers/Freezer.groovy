package com.freezers

class Freezer {
    String name
    int shelves
    int rackspershelf


    static hasMany = [shelves: Shelf]

    static constraints = {
        name size: 1..20, nullable: false
        shelves nullable: false
        rackspershelf nullable : false
    }
}
